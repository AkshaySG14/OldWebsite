# Traffic-Director
Made by Akshay Subramaniam

Traffic director is a very simplistic game made in python. The goal of traffic director is to direct traffic on three intersections,
and ensure that cars get to their destination while not colliding and while not staying on the road too long. The game is operated
via mouse clicks exclusively. The only thing the user has to do is to change the traffic lights on the roads from red to green and 
vice-versa. A red light stops all cars at the intersection, while a green light lets them pass. 

Traffic director was made in Python, and uses the framework pygame to draw the sprites on the screen. The code is extremely 
easy to digest, and is prime learning material for those new to the script.

Unfortunately, I was unable to package the game properly, and the game must be run via python from one's computer, and pygame 
must also be downloaded.
